﻿Public Class DocForm
    '' Private Sub OpenToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles OpenToolStripMenuItem.Click

    ''End Sub
End Class