﻿Option Strict On
Imports System.IO

Public Class frmTextEditor

    Private docNumberInteger As Integer = 0

#Region "New"
    ''<div>Icons made by <a href="https://www.flaticon.com/authors/smashicons" title="Smashicons">Smashicons</a> from <a href="https://www.flaticon.com/"                 title="Flaticon">www.flaticon.com</a> is licensed by <a href="http://creativecommons.org/licenses/by/3.0/"                 title="Creative Commons BY 3.0" target="_blank">CC 3.0 BY</a></div>

    Private Sub NewToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles NewToolStripMenuItem.Click
        Dim docform As New DocForm()
        docform.MdiParent = Me
        docNumberInteger = docNumberInteger + 1
        docform.Text = "New Document " & docNumberInteger
        docform.Show()

    End Sub
    Private Sub OpenToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles OpenToolStripMenuItem.Click


        If OpenFileDialog1.ShowDialog() = DialogResult.OK Then

            docform.MdiParent = Me
            Try
                Dim stream As New StreamReader(OpenFileDialog1.FileName)
                docform.tbTextArea.Text = stream.ReadToEnd
                stream.Close()

                lblStatusStrip.Text = "Open File" + OpenFileDialog1.FileName
                docform.Show()

            Catch ex As Exception

                Throw New ApplicationException(ex.ToString())


            End Try
        End If


    End Sub

    Private Sub CloseToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CloseToolStripMenuItem.Click

        Dim result As Integer = MessageBox.Show("Have You Saved Your Document?", "Warning", MessageBoxButtons.YesNo)
        If result = DialogResult.Yes Then
            DocForm.tbTextArea.Clear()
            MessageBox.Show("New Document Created")
        ElseIf CBool(DialogResult.No) Then
            MessageBox.Show("Please Save Document")
        End If

        If (Me.MdiChildren.Length > 0) Then
            Dim activeForm As DocForm = DirectCast(Me.ActiveMdiChild, DocForm)
            activeForm.Close()

            lblStatusStrip.Text = "Form" + OpenFileDialog1.FileName + " Is Closed"

        End If

    End Sub


    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click

        Application.Exit()

    End Sub

#End Region
#Region "Windows"


    Private Sub TileHorizontallyToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles TileHorizontallyToolStripMenuItem.Click
        LayoutMdi(MdiLayout.TileHorizontal)
    End Sub

    Private Sub TileVerticallyToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles TileVerticallyToolStripMenuItem.Click
        LayoutMdi(MdiLayout.TileVertical)
    End Sub

    Private Sub CascadeToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CascadeToolStripMenuItem.Click
        LayoutMdi(MdiLayout.Cascade)
    End Sub
#End Region
#Region "About"

    Private Sub AboutProgramToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AboutProgramToolStripMenuItem.Click

        MsgBox("Author: Sarah McCann-Hughes" + vbCrLf + "Class: NetD 2202" + vbCrLf + "Lab: #6", MsgBoxStyle.OkOnly, "About")

    End Sub


#End Region
#Region "File Edit"
    Private Sub CopyToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CopyToolStripMenuItem.Click
        ''<div>Icons made by <a href= "https://www.flaticon.com/authors/tomas-knop" title="Tomas Knop">Tomas Knop</a> from <a href="https://www.flaticon.com/"                 title="Flaticon">www.flaticon.com</a> is licensed by <a href="http://creativecommons.org/licenses/by/3.0/"                 title="Creative Commons BY 3.0" target="_blank">CC 3.0 BY</a></div>

        DocForm.tbTextArea.Copy()

    End Sub

    Private Sub CutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CutToolStripMenuItem.Click

        DocForm.tbTextArea.Cut()
    End Sub

    Private Sub PasteToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PasteToolStripMenuItem.Click

        DocForm.tbTextArea.Paste()

    End Sub

#End Region
#Region "Save"
    Private Sub SaveAsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SaveAsToolStripMenuItem.Click

        ''<div>Icons made by <a href="https://www.flaticon.com/authors/smashicons" title="Smashicons">Smashicons</a> from <a href="https://www.flaticon.com/"                 title="Flaticon">www.flaticon.com</a> is licensed by <a href="http://creativecommons.org/licenses/by/3.0/"                 title="Creative Commons BY 3.0" target="_blank">CC 3.0 BY</a></div>


        'Try
        '    Dim myfile As String
        '    Dim saveFileDialog1 As New SaveFileDialog()
        '    myfile = ActiveMdiChild.Text
        '    saveFileDialog1.OverwritePrompt = True
        '    saveFileDialog1.FileName = myfile
        '    saveFileDialog1.Filter = "Rich Text Format (*.rtf)|*.rtf|All files (*.*)|*.*"
        '    saveFileDialog1.ShowDialog()
        '    If saveFileDialog1.FileName = "" Then
        '        Exit Sub
        '    End If



        'Catch
        '    MessageBox.Show("No File To Save Exist", "Error!", MessageBoxButtons.OK,
        '                   MessageBoxIcon.Error)
        'End Try


        If SaveFileDialog1.ShowDialog() = DialogResult.OK Then
            Try
                Dim activeForm As DocForm = DirectCast(Me.ActiveMdiChild, DocForm)

                My.Computer.FileSystem.WriteAllText(SaveFileDialog1.FileName, activeForm.tbTextArea.Text, False)
            Catch ex As Exception
                MessageBox.Show("No File To Save Exist", "Error!", MessageBoxButtons.OK,
                           MessageBoxIcon.Error)
            End Try
        End If

    End Sub

    Private Sub SaveToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SaveToolStripMenuItem.Click

        Dim myfile As String
        Dim saveFileDialog1 As New SaveFileDialog()
        myfile = ActiveMdiChild.Text
        saveFileDialog1.OverwritePrompt = True
        saveFileDialog1.FileName = myfile
        saveFileDialog1.Filter = "Rich Text Format (*.rtf)|*.rtf|All files (*.*)|*.*"
        saveFileDialog1.ShowDialog()
        If saveFileDialog1.FileName = "" Then
            Exit Sub
        End If

    End Sub
#End Region
End Class
